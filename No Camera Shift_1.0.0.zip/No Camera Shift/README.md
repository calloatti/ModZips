﻿No Camera Shift

https://github.com/calloatti/No-Camera-Shift

https://steamcommunity.com/sharedfiles/filedetails/?id=3696473054

Mods on GitHub

https://github.com/search?q=owner%3Acalloatti+sort%3Aname-asc+%22Timberborn+Mod%22&type=repositories

Mods on Steam Workshop

https://steamcommunity.com/sharedfiles/filedetails/?id=3682179025

Mods zip files

https://github.com/calloatti/ModZips
